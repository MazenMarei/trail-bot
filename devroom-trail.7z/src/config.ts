export default {
    token       : "NzkwNjU4NDk0ODQzMzIyMzY4.GX5N5F.fKYiQEzojtkQq7rpEQZcXlY7qBpQ5HDhrNPOF4",
    prefix      : "-",
    Mongoose    :"mongodb+srv://kils:011maz787@cluster0.d3re0.mongodb.net/new_Bots",
    debugMode   : true,
    joinChannelID : "866187063895523349",
    reminderTime : "3:28",
    dailyReminder : {guild : "834141462089170964" , channel : "882047782741999636"}
}
