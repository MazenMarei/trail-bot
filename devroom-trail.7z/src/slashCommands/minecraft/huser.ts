import { ActionRowBuilder, ApplicationCommandOptionType, ChatInputCommandInteraction, EmbedBuilder, StringSelectMenuBuilder,Collection, GuildMember } from "discord.js";
const userData = new Map()
 
export default {
    userData : userData,
	name: "huser",
	description: "get hypixel user information",
	permissions: [""],
	roleRequired: "", // id here
	cooldown: 0, // in ms
	options: [{ name: "username", description: "please specify a hypixel username", required: true, type: ApplicationCommandOptionType.String }],
	function: async function ({ interaction }: { interaction: ChatInputCommandInteraction }) {
        let palyername = interaction.options.getString("user")
        let playerID = await getId(palyername)
        console.log(playerID);
        
    }
}


async function getId(playername:string) {
    const data = await fetch(`https://mcuuid.net/?q=${playername}`);
    const player = await data.json();
    return player;
  }